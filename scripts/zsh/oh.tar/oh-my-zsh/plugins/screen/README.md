# screen

This plugin sets title and hardstatus of the tab window for [screen](https://www.gnu.org/software/screen/),
the terminal multiplexer.

To use it add `screen` to the plugins array in your zshrc file.

```zsh
plugins=(... screen)
```
